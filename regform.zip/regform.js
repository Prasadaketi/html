function saveregdata() {
	alert(document.getElementById("regdata").value);
	alert(document.getElementById("regdata1").value);
	alert(document.getElementById("regdata2").value);
	alert(document.getElementById("regdata3").value);
	alert(document.getElementById("regdata4").value);
	alert(document.getElementById("regdata5").value);
	alert(document.getElementById("regdata6").value);
	alert(document.getElementById("regdata7").value);
}
